
package trasportadora.vehiculo;
public class Camion extends Vehiculo{ 
    //extends hace que el programa reconosca la clase camion como una extencion o hijo de Vehiculo//
    //sin extenden no se puede usar las funciones ni las variables del padre//
    
    int ejes;
    
    public Camion(String placa,String marca,int ejes){//se reconocen las variables del padre//
    
        super(placa, marca, "Camion");//super trae la funcion del padre y cambia tipo por Camion//
        this.ejes = ejes;
    
    }
    //se llama la funcion padre con el Override//
   @Override
    public void mostrarInfo(){
    
        super.mostrarInfo();
         System.out.println("Numero de ejes: " + ejes);
    
    }
    
    
}
