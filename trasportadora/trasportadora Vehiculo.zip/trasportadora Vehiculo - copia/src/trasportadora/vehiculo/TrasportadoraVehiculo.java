
package trasportadora.vehiculo;
import java.util.Scanner; //se llama el scanner desde el paquete de java.util//
//esto permite leer el teclado//

public class TrasportadoraVehiculo {

     public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); //esto permite leer lo que escribe el usuario//
        
        
                            //el menú//
        System.out.println("Bienvenido a la empresa transportadora!");
        System.out.println("Elige el tipo de producto a transportar:");
        System.out.println("1. Alimentos (necesitan refrigeracion)");
        System.out.println("2. Liquidos (como agua o combustible)");
        System.out.println("3. Paquetes ligeros (cosas pequenas y rapidas)");
        System.out.println("4. Carga pesada (cosas grandes y pesadas)");
        System.out.print("Ingresa el numero (1-4): ");
        int opcion = scanner.nextInt();
        scanner.nextLine(); // Para "limpiar" el enter//
        
             // Pedir salida y llegada//
        System.out.print("Lugar de salida: ");
        String salida = scanner.nextLine();
        System.out.print("Lugar de llegada: ");
        String llegada = scanner.nextLine();
        
        //se crean los vehiculos con su placa y mar y todas sus huevadas//
        Vehiculo vehiculoAsignado = null;
        if (opcion == 1) {
            
                   // Alimentos -> Furgon con refrigeracion//
            vehiculoAsignado = new Furgon("ABC-123", "Mercedes", true);
        } else if (opcion == 2) {
            
                                   // Liquidos -> Cisterna//
            vehiculoAsignado = new Sisterna("DEF-456", "Volvo", 5000, "Agua", "Acero");
        } else if (opcion == 3) {
            
                           // Paquetes ligeros -> Liviano//
            vehiculoAsignado = new Liviano("GHI-789", "Toyota", 500, 120);
            
        } else if (opcion == 4) {
                        //Carga pesada -> Camion//
            vehiculoAsignado = new Camion("JKL-012", "Scania", 4);
            
                //si se ingresa algo que no es entonces//
        } else {
            System.out.println("Opcion invalida. Saliendo...");
            return;
        }
        
                         // Mostrar un resumen//
        System.out.println("\nResumen del transporte:");
        System.out.println("Producto: " + (opcion == 1 ? "Alimentos" : opcion == 2 ? "Liquidos" : opcion == 3 ? "Paquetes ligeros" : "Carga pesada"));
        System.out.println("De: " + salida);
        System.out.println("A: " + llegada);
        System.out.println("Vehiculo asignado:");
        vehiculoAsignado.mostrarInfo();
        
     }
    
}
