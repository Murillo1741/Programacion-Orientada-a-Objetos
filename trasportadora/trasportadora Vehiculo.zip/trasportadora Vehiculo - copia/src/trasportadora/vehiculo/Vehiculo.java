
package trasportadora.vehiculo;

public class Vehiculo {
    
  String placa;
  String marca;
  String tipo;
  
  
  public Vehiculo( String placa,String marca,String tipo){
  
      this.placa = placa;
      this.marca = marca;
      this.tipo = tipo;
  }
    
  //esta funcion que se reparte en los hijos//
  public void mostrarInfo(){
  
  System.out.println("Placa= " + placa);
   System.out.println("Marca= " + marca);
    System.out.println("Tipo de vehiculo= " + tipo);
      
  }
}
