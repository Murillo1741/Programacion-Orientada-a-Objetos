
package trasportadora.vehiculo;

public class Sisterna extends Vehiculo{
    //el extende lo esplique en la variable comion//
    //resumen: sin el no funciona nada//
    
    double capacidad;
    String tipoLiquido;
    String materialTanque;
    
    
    public Sisterna(String placa, String marca, double capacidad,String tipoLiquido, String materialTanque){
    //se reconocen las variables del padre//
    
    super(placa, marca,"Cisterna");//se sustituye tipo//
    this.capacidad = capacidad;
    this.tipoLiquido = tipoLiquido;
    this.materialTanque = materialTanque;
    }
   
    @Override //se llama la funcion del padre//
    public void mostrarInfo() {
        super.mostrarInfo();
        System.out.println("Capacidad de liquido: " + capacidad + " litros");
        System.out.println("Tipo de liquido: " + tipoLiquido);
        System.out.println("Material del tanque: " + materialTanque);
    }
    
}
