
package trasportadora.vehiculo;

public class Furgon extends Vehiculo {
    
    boolean refrigeracion;
    
    
    public Furgon(String placa, String marca, boolean refrigeracion){
    
    super(placa,marca,"Furgon");
    this.refrigeracion = refrigeracion;    
    }
    
    @Override
    
    public void mostrarInfo(){
    
        super.mostrarInfo();
        System.out.println("Refrigeracion: " + (refrigeracion ? "si" : "no" ));
    
    }
    
}
