
package trasportadora.vehiculo;

public class Liviano extends Vehiculo {
    
    double Peso; // En kg
    double velocidadMaxima; // En km/h
    
    public Liviano(String placa, String marca, double Peso, double velocidadMaxima){
    
        super(placa, marca, "Liviano");
        this.Peso = Peso;
        this.velocidadMaxima = velocidadMaxima;
    }
    
    @Override
    public void mostrarInfo() {
        super.mostrarInfo();
        System.out.println("Capacidad de peso: " + Peso + " kg");
        System.out.println("Velocidad maxima: " + velocidadMaxima + " km/h");
    }
    
}
