
package trasportadora.persona;

/**
 *
 * @author sbxxs
 */
public class Conductor extends Persona{
    
    long licencia;
    int experiencia;

    public Conductor(long documento, String nombre, long telefono, long licencia, int experiencia){
    
        super(documento,nombre,telefono);
        this.licencia = licencia;
        this.experiencia = experiencia;
    
    }
    
    
    
    @Override
    public String mostrarInfo(){
    
        return "("+ this.documento + ", "
                +this.nombre +","
                +this.telefono +")"
                +this.licencia +")"
                +this.experiencia +")";
    
    
    
}
}
