
package trasportadora.persona;
import java.util.Scanner; //se llama el scanner desde el paquete de java.util//
//esto permite leer el teclado//

public class TrasportadoraPersona {

    public static void main(String[] args) {
        
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.println("Bienvenido al sistema de registro de la empresa transportadora.");
            System.out.println("Seleccione el tipo de registro:");
            System.out.println("1. Empleado");
            System.out.println("2. Conductor");
            System.out.println("3. Cliente");
            System.out.print("Opción: ");
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Consumir el salto de línea
            
            switch (opcion) {
                case 1 -> registrarEmpleado(scanner);
                case 2 -> registrarConductor(scanner);
                case 3 -> registrarCliente(scanner);
                default -> System.out.println("Opción inválida.");
            }
        }
    }

    private static void registrarEmpleado(Scanner scanner) {
        System.out.println("Registro de Empleado:");
        System.out.print("Documento: ");
        long documento = scanner.nextLong();
        scanner.nextLine();
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        System.out.print("Teléfono: ");
        long telefono = scanner.nextLong();
        
        System.out.print("Código: ");
        long codigo = scanner.nextLong();
        Empleado empleado = new Empleado(documento, nombre, telefono, codigo);
        System.out.println("Empleado registrado exitosamente:");
        System.out.println(empleado);
    }
    
private static void registrarConductor(Scanner scanner) {
        System.out.println("Registro de Conductor:");
        System.out.print("Documento: ");
        long documento = scanner.nextLong();
        scanner.nextLine();
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        System.out.print("Teléfono: ");
        long telefono = scanner.nextLong();
        System.out.print("Licencia: ");
        long licencia = scanner.nextLong();
        System.out.print("cuantos años de experiencia tienes? : ");
        int experiencia = scanner.nextInt();
        Conductor conductor = new Conductor(documento, nombre, telefono, licencia, experiencia);
        System.out.println("Conductor registrado exitosamente:");
        System.out.println(conductor);
    }
private static void registrarCliente(Scanner scanner) {
        System.out.println("Registro de Cliente:");
        System.out.print("Documento: ");
        long documento = scanner.nextLong();
        scanner.nextLine();
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        System.out.print("Teléfono: ");
        long telefono = scanner.nextLong();
        System.out.print("¿Es jurídico? (true/false): ");
        boolean juridico = scanner.nextBoolean();
        System.out.print("Número de pedidos: ");
        int numeroServicios = scanner.nextInt();
        Cliente cliente = new Cliente(documento, nombre, telefono, juridico, numeroServicios);
        System.out.println("Cliente registrado exitosamente:");
        System.out.println(cliente);
    }
}
