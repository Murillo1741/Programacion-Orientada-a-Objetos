
package trasportadora.persona;
public class Empleado extends Persona{
    
    long codigo;

public Empleado(long documento, String nombre, long telefono, long codigo){
        
    super(documento,nombre,telefono);
    this.codigo = codigo;
        
    }
   
    
    @Override
    public String mostrarInfo(){
    
        return "("+ this.documento + ", "
                +this.nombre +","
                +this.telefono +")"
                +this.codigo +")";
    
}
}

