
package trasportadora.persona;

public class Cliente extends Persona{
    
      boolean juridico;
     int numeroServicios;

    public Cliente(long documento, String nombre, long telefono, boolean juridico, int numeroServicios) {
        
        super(documento,nombre,telefono);
        this.juridico = juridico;
        this.numeroServicios = numeroServicios;
        
    }
    
    
    @Override
    public String mostrarInfo(){
    
        return "("+ this.documento + ", "
                +this.nombre +","
                +this.telefono +")"
                +this.juridico +")"
                +this.numeroServicios +")";
    
    
    
}
    
}
