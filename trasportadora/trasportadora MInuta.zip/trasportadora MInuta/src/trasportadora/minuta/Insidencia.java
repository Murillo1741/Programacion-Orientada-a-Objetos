
package trasportadora.minuta;
public class Insidencia {
   
    public String hora;
    public String observaciones;
    public String imagenSatelital; // Simulamos como una cadena, ej. "Imagen de satélite: ruta clara"

    // Constructor
    public Insidencia(String hora, String observaciones, String imagenSatelital) {
        this.hora = hora;
        this.observaciones = observaciones;
        this.imagenSatelital = imagenSatelital;
    }
}