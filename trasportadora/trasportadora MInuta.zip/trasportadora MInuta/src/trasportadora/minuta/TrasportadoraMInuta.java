
package trasportadora.minuta;
import java.util.Scanner; // Para leer entrada del usuario//

public class TrasportadoraMInuta {
    public static void main(String[] args) {
        
        Minuta minuta = new Minuta();
        
        // Usamos Scanner para pedir datos //
        Scanner scanner = new Scanner(System.in);
        
        // Simulamos 5 horas (en realidad, esperamos 1 segundo cada vez para probar)//
        for (int i = 1; i <= 5; i++) {
            System.out.println("Registrando incidencia para la hora " + i + ":00");
            
            // Pedimos observaciones al usuario//
            System.out.print("Escribe las observaciones: ");
            String obs = scanner.nextLine();
            
            // Pedimos imagen satelital (simulada como texto)//
            System.out.print("Escribe la imagen satelital (ej. 'Imagen clara del camino'): ");
            String img = scanner.nextLine();
            
            // Creamos la incidencia//
            Insidencia inc = new Insidencia(i + ":00", obs, img);
            
            // Agregamos a la minuta//
            minuta.agregarIncidencia(inc);
            
            // Esperamos 1 segundo (simulando 1 hora)//
            try {
                Thread.sleep(1000); // 1000 ms = 1 segundo//
            } catch (InterruptedException e) {
                
            }
        }
        
        // Mostramos la minuta al final//
        minuta.mostrarMinuta();
        
        // Cerramos el scanner//
        scanner.close();
    }
}