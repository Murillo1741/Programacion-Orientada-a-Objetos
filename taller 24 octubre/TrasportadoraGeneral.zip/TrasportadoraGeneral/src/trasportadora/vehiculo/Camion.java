package trasportadora.vehiculo;

public class Camion extends Vehiculo {
    int ejes;

    public Camion(String placa, String marca, int ejes) {
        super(placa, marca);
        this.ejes = ejes;
    }

  
    @Override
    public void mostrarInfo() {
        System.out.println("Vehículo tipo Camión");
        System.out.println("Placa: " + placa + ", Marca: " + marca + ", Ejes: " + ejes);
    }
}

