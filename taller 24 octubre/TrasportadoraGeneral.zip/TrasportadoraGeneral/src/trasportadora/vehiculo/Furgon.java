package trasportadora.vehiculo;

public class Furgon extends Vehiculo {
    boolean refrigeracion;

    public Furgon(String placa, String marca, boolean refrigeracion) {
        super(placa, marca);
        this.refrigeracion = refrigeracion;
    }

   
    @Override
    public void mostrarInfo() {
        System.out.println("Vehículo tipo Furgón");
        System.out.println("Placa: " + placa + ", Marca: " + marca + ", Refrigeración: " + refrigeracion);
    }
}

