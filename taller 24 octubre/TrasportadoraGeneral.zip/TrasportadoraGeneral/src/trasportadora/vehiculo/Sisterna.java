package trasportadora.vehiculo;

public class Sisterna extends Vehiculo {
    int capacidad;
    String tipoLiquido;
    String material;

    public Sisterna(String placa, String marca, int capacidad, String tipoLiquido, String material) {
        super(placa, marca);
        this.capacidad = capacidad;
        this.tipoLiquido = tipoLiquido;
        this.material = material;
    }

   
    @Override
    public void mostrarInfo() {
        System.out.println("Vehículo tipo Sisterna");
        System.out.println("Placa: " + placa + ", Marca: " + marca);
        System.out.println("Capacidad: " + capacidad + "L, Tipo: " + tipoLiquido + ", Material: " + material);
    }
}
