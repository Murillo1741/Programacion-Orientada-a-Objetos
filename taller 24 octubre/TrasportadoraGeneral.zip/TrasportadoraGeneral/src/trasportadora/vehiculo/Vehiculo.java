
package trasportadora.vehiculo;

public abstract class Vehiculo {
    String placa;
    String marca;

    public Vehiculo(String placa, String marca) {
        this.placa = placa;
        this.marca = marca;
    }

    public abstract void mostrarInfo();
}

