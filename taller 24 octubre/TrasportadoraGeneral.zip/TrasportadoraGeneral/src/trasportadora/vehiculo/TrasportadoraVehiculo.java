package trasportadora.vehiculo;

import java.util.Scanner;

public class TrasportadoraVehiculo {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("\n=== CREACIÓN DE SERVICIO ===");
        System.out.println("1. Alimentos (necesitan refrigeración)");
        System.out.println("2. Líquidos (agua o combustible)");
        System.out.println("3. Paquetes ligeros");
        System.out.println("4. Carga pesada");
        System.out.print("Elige el tipo de producto (1-4): ");
        int opcion = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Lugar de salida: ");
        String salida = scanner.nextLine();
        System.out.print("Lugar de llegada: ");
        String llegada = scanner.nextLine();

        Vehiculo vehiculoAsignado = null;

        switch (opcion) {
            case 1 -> vehiculoAsignado = new Furgon("ABC-123", "Mercedes", true);
            case 2 -> vehiculoAsignado = new Sisterna("DEF-456", "Volvo", 5000, "Agua", "Acero");
            case 3 -> vehiculoAsignado = new Liviano("GHI-789", "Toyota", 500, 120);
            case 4 -> vehiculoAsignado = new Camion("JKL-012", "Scania", 4);
            default -> {
                System.out.println("Opción inválida. Saliendo...");
                return;
            }
        }

        System.out.println("\nResumen del servicio:");
        System.out.println("Producto: " + (opcion == 1 ? "Alimentos" : opcion == 2 ? "Líquidos" : opcion == 3 ? "Paquetes ligeros" : "Carga pesada"));
        System.out.println("Salida: " + salida);
        System.out.println("Llegada: " + llegada);
        vehiculoAsignado.mostrarInfo();
    }
}
