package trasportadora.vehiculo;

public class Liviano extends Vehiculo {
    int pesoMax;
    int velocidadMax;

    public Liviano(String placa, String marca, int pesoMax, int velocidadMax) {
        super(placa, marca);
        this.pesoMax = pesoMax;
        this.velocidadMax = velocidadMax;
    }

 
    @Override
    public void mostrarInfo() {
        System.out.println("Vehículo tipo Liviano");
        System.out.println("Placa: " + placa + ", Marca: " + marca + ", Peso Máx: " + pesoMax + ", Vel Máx: " + velocidadMax);
    }
}

