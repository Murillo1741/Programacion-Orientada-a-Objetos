package trasportadora.minuta;

import java.util.Scanner;

public class TrasportadoraMInuta {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("\n=== CREAR MINUTA ===");
        System.out.print("Ingrese hora de salida: ");
        String horaSalida = sc.nextLine();
        System.out.print("Ingrese observaciones iniciales: ");
        String observaciones = sc.nextLine();

        System.out.println("\nMinuta creada:");
        System.out.println("Hora de salida: " + horaSalida);
        System.out.println("Observaciones: " + observaciones);
    }
}
