
package trasportadora.minuta;
import java.util.ArrayList; // Importamos para la lista
import java.util.List;

public class Minuta {
   
    public List<Insidencia> listaIncidencias = new ArrayList<>();

 
    public void agregarIncidencia(Insidencia inc) {
        listaIncidencias.add(inc);
    }

    public void mostrarMinuta() {
        System.out.println("Minuta de la empresa transportadora:");
        for (Insidencia inc : listaIncidencias) {
            System.out.println("Hora: " + inc.hora);
            System.out.println("Observaciones: " + inc.observaciones);
            System.out.println("Imagen Satelital: " + inc.imagenSatelital);
            System.out.println("---");
        }
    }
}
