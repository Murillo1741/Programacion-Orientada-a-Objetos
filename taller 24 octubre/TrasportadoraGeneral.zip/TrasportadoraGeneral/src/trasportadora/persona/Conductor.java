
package trasportadora.persona;

/**
 *
 * @author sbxxs
 */
public class Conductor extends Persona{
    
    String licencia;
    int experiencia;

    public Conductor(String nombre,long documento, long telefono, String licencia, int experiencia){
    
        super(documento,nombre,telefono);
        this.licencia = licencia;
        this.experiencia = experiencia;
    
    }
    
    
    
    @Override
    public String mostrarInfo(){
    
        return "("+ this.documento + ", "
                +this.nombre +","
                +this.telefono +")"
                +this.licencia +")"
                +this.experiencia +")";
    
    
    
}
}
