
package trasportadora.persona;


public class Persona {
    long documento;
    String nombre;
    long telefono;
   

    public Persona(long documento, String nombre, long telefono) {
        this.documento = documento;
        this.nombre = nombre;
        this.telefono = telefono;
        
    }
    
    public String mostrarInfo(){
    
        return "("+ this.documento + ", "
                +this.nombre +","
                +this.telefono +")" ;
                                      
    }
    
    
  
}
