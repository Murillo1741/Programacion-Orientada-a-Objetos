
package trasportadora.persona;
public class Cliente {
    long documento;
    String nombre;
    long telefono;
    boolean juridico;
    long numeroServicios;

    public Cliente(long documento, String nombre, long telefono, boolean juridico, long numeroServicios) {
        this.documento = documento;
        this.nombre = nombre;
        this.telefono = telefono;
        this.juridico = juridico;
        this.numeroServicios = numeroServicios;
    }

    public void mostrarInfo() {
        System.out.println("Documento: " + this.documento);
        System.out.println("Nombre: " + this.nombre);
        System.out.println("Teléfono: " + this.telefono);
        System.out.println("Cliente jurídico: " + this.juridico);
        System.out.println("Número de servicios: " + this.numeroServicios);
    }
}
