package trasportadora.sistema;

import java.util.Scanner;
import trasportadora.persona.Cliente;
import trasportadora.vehiculo.TrasportadoraVehiculo;
import trasportadora.minuta.TrasportadoraMInuta;

public class TrasportadoraGeneral {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        String usuarioCorrecto = "admin";
        String contrasenaCorrecta = "1234";

        Cliente cliente = null;
        String nombreConductor = null;
        long documentoConductor = 0;
        long telefonoConductor = 0;
        String licenciaConductor = null;

        boolean salir = false;

        System.out.println("=======================================");
        System.out.println("   SISTEMA DE LA EMPRESA TRANSPORTADORA");
        System.out.println("=======================================");

        // LOGIN
        System.out.print("Usuario: ");
        String usuario = teclado.nextLine();
        System.out.print("Contraseña: ");
        String contrasena = teclado.nextLine();

        if (!usuario.equals(usuarioCorrecto) || !contrasena.equals(contrasenaCorrecta)) {
            System.out.println("\nUsuario o contraseña incorrectos. Acceso denegado.");
            return;
        }

        System.out.println("\nBienvenido al sistema, " + usuario + "!");

        // MENÚ PRINCIPAL
        while (!salir) {
            System.out.println("\n=========== MENU PRINCIPAL ===========");
            System.out.println("1. Registrar cliente");
            System.out.println("2. Registrar conductor");
            System.out.println("3. Crear servicio");
            System.out.println("4. Ver información guardada");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opción: ");
            int opcion = teclado.nextInt();
            teclado.nextLine(); // limpiar

            switch (opcion) {
                case 1:
                    System.out.println("\n=== REGISTRO DE CLIENTE ===");
                    System.out.print("Documento: ");
                    long doc = teclado.nextLong();
                    teclado.nextLine();
                    System.out.print("Nombre: ");
                    String nom = teclado.nextLine();
                    System.out.print("Teléfono: ");
                    long tel = teclado.nextLong();
                    System.out.print("¿Es cliente jurídico? (true/false): ");
                    boolean jur = teclado.nextBoolean();
                    System.out.print("Número de servicios solicitados: ");
                    long numServ = teclado.nextLong();

                    cliente = new Cliente(doc, nom, tel, jur, numServ);
                    System.out.println("\nCliente registrado con éxito.");
                    cliente.mostrarInfo();
                    break;

                case 2:
                    System.out.println("\n=== REGISTRO DE CONDUCTOR ===");
                    System.out.print("Documento: ");
                    documentoConductor = teclado.nextLong();
                    teclado.nextLine();
                    System.out.print("Nombre: ");
                    nombreConductor = teclado.nextLine();
                    System.out.print("Teléfono: ");
                    telefonoConductor = teclado.nextLong();
                    teclado.nextLine();
                    System.out.print("Licencia: ");
                    licenciaConductor = teclado.nextLine();

                    System.out.println("\nConductor registrado correctamente.");
                    break;

                case 3:
                    if (cliente == null) {
                        System.out.println("\nPrimero debe registrar un cliente.");
                    } else if (nombreConductor == null) {
                        System.out.println("\nPrimero debe registrar un conductor.");
                    } else {
                        System.out.println("\n=== CREACIÓN DE SERVICIO ===");
                        TrasportadoraVehiculo.main(new String[0]); // crea el servicio
                        TrasportadoraMInuta.main(new String[0]);   // crea la minuta
                        System.out.println("\nServicio y minuta creados correctamente.");
                    }
                    break;

                case 4:
                   System.out.println("\n=== INFORMACIÓN GUARDADA ===");
                    if (cliente != null) {
                        System.out.println("\nCliente:");
                        cliente.mostrarInfo();
                    } else {
                        System.out.println("\nNo hay cliente registrado.");
                    }

                    if (nombreConductor != null) {
                        System.out.println("\nConductor:");
                        System.out.println("Documento: " + documentoConductor);
                        System.out.println("Nombre: " + nombreConductor);
                        System.out.println("Teléfono: " + telefonoConductor);
                        System.out.println("Licencia: " + licenciaConductor);
                    } else {
                        System.out.println("\nNo hay conductor registrado.");
                    }

                    System.out.println("\n(Nota: los servicios creados se muestran en pantalla al generarlos)");
                    break;

                case 5:
                    System.out.println("Saliendo del sistema...");
                    salir = true;
                    break;

                default:
                    System.out.println("Opción no válida.");
            }
        }
    }
}
